
import React from 'react'

function App() {
  return (
    <div style={{ fontFamily: 'Arial', padding: '2rem' }}>
      <h1>Bozorchi tizimi ishga tushdi 🚀</h1>
      <p>Bu sayt test versiyasidir.</p>
    </div>
  )
}

export default App
